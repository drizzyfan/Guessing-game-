# will u get promoted?

A Pen created on CodePen.io. Original URL: [https://codepen.io/maya-alnowami/pen/dyrqmyq](https://codepen.io/maya-alnowami/pen/dyrqmyq).

